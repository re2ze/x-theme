<?php
/**
 ** Custom template tags for this theme.
 **
 ** Eventually, some of the functionality here could be replaced by core features.
 **
 ** @package REGZ TEMPLATE
 ** @since 1.0.0
 **/


