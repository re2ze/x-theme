<?php



define( 'ELEPHAS_DEBUG', TRUE );


if( !function_exists( 'regz_templates_get_theme_v' ) ):
  
/**
 ** Returns theme version.
 **
 ** @package REGZ TEMPLATE
 ** @since 1.0.0
 ** @return string
 **/
function regz_templates_get_theme_v() {

  $theme = wp_get_theme();
  return $theme->get('Version');

}


endif;


if( !function_exists( 'regz_templates_script_prefix' ) ):
  
/**
 ** Returns theme version.
 **
 ** @package REGZ TEMPLATE
 ** @since 1.0.0
 ** @return string
 **/
function regz_templates_script_prefix() {

  return ELEPHAS_DEBUG ? '' : '.min';

}

endif;

