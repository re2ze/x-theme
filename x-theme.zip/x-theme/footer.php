<?php
/**
 ** The template for displaying the footer.
 **
 ** Contains most of the closing tags
 **
 ** @package X-Theme
 ** @since 1.0.0
 **/
?>
	
<footer id="main-footer" class="full-width main-footer">
	<h4>footer</h4>
</footer>

<?php wp_footer(); ?>
</body>
</html>